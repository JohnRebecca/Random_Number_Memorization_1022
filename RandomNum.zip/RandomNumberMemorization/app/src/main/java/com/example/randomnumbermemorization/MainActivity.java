package com.example.randomnumbermemorization;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {
    private Button bStart,bInstruction,bScore, bBack, bBack2, bBackHome, bPeace, bSurvive, bHard, bNext, bNext2, bNext3,bNextSur0, bNextSur, bNextSur2, bNextHar0, bNextHar1, bNextHard2;
    ArrayList<Integer> randArray = new ArrayList<>() ;
    ArrayList<Integer> randArraySurvive = new ArrayList<>() ;
    ArrayList<Integer> randArrayHardcore = new ArrayList<>() ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bStart = (Button) findViewById(R.id.button1);
        bInstruction = (Button) findViewById(R.id.button2);
        bScore = (Button) findViewById(R.id.button3);
        bPeace = (Button) findViewById(R.id.buttonPeaceful);
        bSurvive = (Button) findViewById(R.id.buttonSurvival);
        bHard = (Button) findViewById(R.id.buttonHardcore);
        bBack2 = (Button) findViewById(R.id.buttonBack1);
        bBack = (Button) findViewById(R.id.buttonBack);
        bNext = (Button) findViewById(R.id.buttonNext);
        bNext2 = (Button) findViewById(R.id.buttonNext2);
        bNext3 = (Button) findViewById(R.id.buttonNext3);
        bNextSur = (Button) findViewById(R.id.buttonNextSurvive);
        bNextSur2 = (Button) findViewById(R.id.buttonNextSur2);
        bNextSur0 = (Button) findViewById(R.id.buttonNextSur0);
        bNextHar0 = (Button) findViewById(R.id.buttonNextHard0);
        bNextHar1 = (Button) findViewById(R.id.buttonNextHar1);
        bNextHard2 = (Button) findViewById(R.id.buttonNextHar2);
        bBackHome = (Button) findViewById(R.id.buttonBacktoHome);
        TextView textViewRandom =(TextView) findViewById(R.id.textViewRandom);
        bPeace.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("SetText18n")
            @Override
            public void onClick(View view) {
                Random random = new Random();
                int randomNum = random.nextInt(10);
                randArray.add(randomNum);
                textViewRandom.setText(Integer.toString(randomNum));
                bStart.setVisibility(View.INVISIBLE);
                bInstruction.setVisibility(View.INVISIBLE);
                bScore.setVisibility(View.INVISIBLE);
                TextView textView =(TextView) findViewById(R.id.textView2);
                textView.setVisibility(View.INVISIBLE);
                bBack2.setVisibility(View.VISIBLE);
                bPeace.setVisibility(View.INVISIBLE);
                bSurvive.setVisibility(View.INVISIBLE);
                bHard.setVisibility(View.INVISIBLE);
                TextView textView3 =(TextView) findViewById(R.id.textView3);
                textView3.setVisibility(View.VISIBLE);
                TextView textViewRan =(TextView) findViewById(R.id.textViewRandom);
                textViewRan.setVisibility(View.VISIBLE);
                bNext.setVisibility(View.VISIBLE);
                bBackHome.setVisibility(View.INVISIBLE);
            }
        });



    }
    public void bStartClicked(View v){
        bStart.setVisibility(View.INVISIBLE);
        bInstruction.setVisibility(View.INVISIBLE);
        bScore.setVisibility(View.INVISIBLE);
        bBackHome.setVisibility(View.VISIBLE);
        bPeace.setVisibility(View.VISIBLE);
        bSurvive.setVisibility(View.VISIBLE);
        bHard.setVisibility(View.VISIBLE);

    }
    public void bInstructionClicked(View v){
        bStart.setVisibility(View.INVISIBLE);
        bInstruction.setVisibility(View.INVISIBLE);
        bScore.setVisibility(View.INVISIBLE);
        TextView textView =(TextView) findViewById(R.id.textView2);
        textView.setText("Welcome to Random Number memorization, here you will be putting your memory to the test by remembering the numbers that are given to you by our beloved game. \n" +
                "The rules for this game are simple, you will be given a number and your job is to memorize the number and type it into the textbox. " +
                "(Note, when typing multiple numbers, make sure to separate each number with a comma and a space for ex. 4, 3 rather than 43 or 4,3). " +
                "You have 3 brilliant levels to choose from and depending on how brave you are, you are welcome to choose any.  Enjoy!!");
        textView.setVisibility(View.VISIBLE);
        bBack.setVisibility(View.VISIBLE);
        bBackHome.setVisibility(View.INVISIBLE);
    }
    public void bScoreClicked(View v){
        bStart.setVisibility(View.INVISIBLE);
        bInstruction.setVisibility(View.INVISIBLE);
        bScore.setVisibility(View.INVISIBLE);
        bBackHome.setVisibility(View.VISIBLE);
        TextView textViewScore =(TextView) findViewById(R.id.textViewScore);
        textViewScore.setVisibility(View.VISIBLE);
    }
    public void bBackClicked(View v){
        bStart.setVisibility(View.VISIBLE);
        bInstruction.setVisibility(View.VISIBLE);
        bScore.setVisibility(View.VISIBLE);
        TextView textView =(TextView) findViewById(R.id.textView2);
        textView.setVisibility(View.INVISIBLE);
        bBack.setVisibility(View.INVISIBLE);
        bBackHome.setVisibility(View.INVISIBLE);
    }
    public void bBack2Clicked(View v){
        bStart.setVisibility(View.INVISIBLE);
        bInstruction.setVisibility(View.INVISIBLE);
        bScore.setVisibility(View.INVISIBLE);
        TextView textView =(TextView) findViewById(R.id.textView2);
        textView.setVisibility(View.INVISIBLE);
        bBack2.setVisibility(View.INVISIBLE);
        bPeace.setVisibility(View.VISIBLE);
        bSurvive.setVisibility(View.VISIBLE);
        bHard.setVisibility(View.VISIBLE);
        TextView textView3 =(TextView) findViewById(R.id.textView3);
        textView3.setVisibility(View.INVISIBLE);
        TextView textViewResult = (TextView) findViewById(R.id.textViewResult);
        textViewResult.setVisibility(View.INVISIBLE);
        TextView textViewRan =(TextView) findViewById(R.id.textViewRandom);
        textViewRan.setVisibility(View.INVISIBLE);
        bNext.setVisibility(View.INVISIBLE);
        bNext2.setVisibility(View.INVISIBLE);
        bNext3.setVisibility(View.INVISIBLE);
        bNextSur.setVisibility(View.INVISIBLE);
        bNextSur2.setVisibility(View.INVISIBLE);
        bNextSur0.setVisibility(View.INVISIBLE);
        bNextHar0.setVisibility(View.INVISIBLE);
        bNextHar1.setVisibility(View.INVISIBLE);
        bNextHard2.setVisibility(View.INVISIBLE);
        bBackHome.setVisibility(View.VISIBLE);
    }

    public void bNextClicked(View v){
        bStart.setVisibility(View.INVISIBLE);
        bInstruction.setVisibility(View.INVISIBLE);
        bScore.setVisibility(View.INVISIBLE);
        TextView textView =(TextView) findViewById(R.id.textView2);
        textView.setVisibility(View.INVISIBLE);
        bBack2.setVisibility(View.INVISIBLE);
        bPeace.setVisibility(View.INVISIBLE);
        bSurvive.setVisibility(View.INVISIBLE);
        bHard.setVisibility(View.INVISIBLE);
        TextView textView3 =(TextView) findViewById(R.id.textView3);
        textView3.setVisibility(View.INVISIBLE);
        TextView textViewRan =(TextView) findViewById(R.id.textViewRandom);
        textViewRan.setVisibility(View.INVISIBLE);
        EditText editTextInput = (EditText) findViewById(R.id.editTextInput);
        editTextInput.setVisibility(View.VISIBLE);
        bNext.setVisibility(View.INVISIBLE);
        bNext2.setVisibility(View.VISIBLE);
        bBackHome.setVisibility(View.INVISIBLE);
    }
    public void bNext2Clicked(View v){
        bStart.setVisibility(View.INVISIBLE);
        bInstruction.setVisibility(View.INVISIBLE);
        bScore.setVisibility(View.INVISIBLE);
        TextView textView =(TextView) findViewById(R.id.textView2);
        textView.setVisibility(View.INVISIBLE);
        bBack2.setVisibility(View.VISIBLE);
        bPeace.setVisibility(View.INVISIBLE);
        bSurvive.setVisibility(View.INVISIBLE);
        bHard.setVisibility(View.INVISIBLE);
        TextView textView3 =(TextView) findViewById(R.id.textView3);
        textView3.setVisibility(View.INVISIBLE);
        TextView textViewRan =(TextView) findViewById(R.id.textViewRandom);
        textViewRan.setVisibility(View.INVISIBLE);
        bNext.setVisibility(View.INVISIBLE);
        EditText editTextInput = (EditText) findViewById(R.id.editTextInput);
        editTextInput.setVisibility(View.INVISIBLE);
        String arr = randArray.toString();
        String user = editTextInput.getText().toString();
        String userCheck = RandomGen.rndCheck(arr, user);
        TextView textViewResult = (TextView) findViewById(R.id.textViewResult);
        textViewResult.setVisibility(View.VISIBLE);
        textViewResult.setText(userCheck);
        bNext2.setVisibility(View.INVISIBLE);
        bNext3.setVisibility(View.VISIBLE);
        bBackHome.setVisibility(View.INVISIBLE);
    }
    public void bNext3Clicked(View v){
        bStart.setVisibility(View.INVISIBLE);
        bInstruction.setVisibility(View.INVISIBLE);
        bScore.setVisibility(View.INVISIBLE);
        TextView textView =(TextView) findViewById(R.id.textView2);
        textView.setVisibility(View.INVISIBLE);
        bBack2.setVisibility(View.VISIBLE);
        bPeace.setVisibility(View.INVISIBLE);
        bSurvive.setVisibility(View.INVISIBLE);
        bHard.setVisibility(View.INVISIBLE);
        TextView textView3 =(TextView) findViewById(R.id.textView3);
        textView3.setVisibility(View.VISIBLE);
        TextView textViewResult = (TextView) findViewById(R.id.textViewResult);
        textViewResult.setVisibility(View.INVISIBLE);
        TextView textViewRan =(TextView) findViewById(R.id.textViewRandom);
        Random random = new Random();
        int randomNum = random.nextInt(10);
        randArray.add(randomNum);
        textViewRan.setText(Integer.toString(randomNum));
        textViewRan.setVisibility(View.VISIBLE);
        bNext.setVisibility(View.VISIBLE);
        EditText editTextInput = (EditText) findViewById(R.id.editTextInput);
        editTextInput.setVisibility(View.INVISIBLE);
        bNext2.setVisibility(View.INVISIBLE);
        bNext3.setVisibility(View.INVISIBLE);
        bBackHome.setVisibility(View.INVISIBLE);

    }
    public void bSurviveClicked(View v){
        Random random = new Random();
        int randomNum = random.nextInt(99);
        randArraySurvive.add(randomNum);
        TextView textViewRandom =(TextView) findViewById(R.id.textViewRandom);
        textViewRandom.setText(Integer.toString(randomNum));
        bStart.setVisibility(View.INVISIBLE);
        bInstruction.setVisibility(View.INVISIBLE);
        bScore.setVisibility(View.INVISIBLE);
        TextView textView =(TextView) findViewById(R.id.textView2);
        textView.setVisibility(View.INVISIBLE);
        bBack2.setVisibility(View.VISIBLE);
        bPeace.setVisibility(View.INVISIBLE);
        bSurvive.setVisibility(View.INVISIBLE);
        bHard.setVisibility(View.INVISIBLE);
        TextView textView3 =(TextView) findViewById(R.id.textView3);
        textView3.setVisibility(View.VISIBLE);
        TextView textViewRan =(TextView) findViewById(R.id.textViewRandom);
        textViewRan.setVisibility(View.VISIBLE);
        bNextSur0.setVisibility(View.VISIBLE);
        bNext.setVisibility(View.INVISIBLE);
        bNextSur.setVisibility(View.INVISIBLE);
        bBackHome.setVisibility(View.INVISIBLE);
    }
    public void bNextSur0Clicked(View v){

        bStart.setVisibility(View.INVISIBLE);
        bInstruction.setVisibility(View.INVISIBLE);
        bScore.setVisibility(View.INVISIBLE);
        TextView textView =(TextView) findViewById(R.id.textView2);
        textView.setVisibility(View.INVISIBLE);
        bBack2.setVisibility(View.INVISIBLE);
        bPeace.setVisibility(View.INVISIBLE);
        bSurvive.setVisibility(View.INVISIBLE);
        bHard.setVisibility(View.INVISIBLE);
        TextView textView3 =(TextView) findViewById(R.id.textView3);
        textView3.setVisibility(View.INVISIBLE);
        TextView textViewRan =(TextView) findViewById(R.id.textViewRandom);
        textViewRan.setVisibility(View.INVISIBLE);
        bNext.setVisibility(View.VISIBLE);
        EditText editTextInput = (EditText) findViewById(R.id.editTextInput);
        editTextInput.setVisibility(View.VISIBLE);
        bNext.setVisibility(View.INVISIBLE);
        bNext2.setVisibility(View.INVISIBLE);
        bNextSur0.setVisibility(View.INVISIBLE);
        bNextSur.setVisibility(View.VISIBLE);
        bNextSur2.setVisibility(View.INVISIBLE);
        bBackHome.setVisibility(View.INVISIBLE);
    }

    public void bNextSurClicked(View v){
        bStart.setVisibility(View.INVISIBLE);
        bInstruction.setVisibility(View.INVISIBLE);
        bScore.setVisibility(View.INVISIBLE);
        TextView textView =(TextView) findViewById(R.id.textView2);
        textView.setVisibility(View.INVISIBLE);
        bBack2.setVisibility(View.VISIBLE);
        bPeace.setVisibility(View.INVISIBLE);
        bSurvive.setVisibility(View.INVISIBLE);
        bHard.setVisibility(View.INVISIBLE);
        TextView textView3 =(TextView) findViewById(R.id.textView3);
        textView3.setVisibility(View.INVISIBLE);
        TextView textViewRan =(TextView) findViewById(R.id.textViewRandom);
        textViewRan.setVisibility(View.INVISIBLE);
        bNext.setVisibility(View.INVISIBLE);
        EditText editTextInput = (EditText) findViewById(R.id.editTextInput);
        editTextInput.setVisibility(View.INVISIBLE);
        String arr = randArraySurvive.toString();
        String user = editTextInput.getText().toString();
        String userCheck = RandomGen.rndCheck(arr, user);
        TextView textViewResult = (TextView) findViewById(R.id.textViewResult);
        textViewResult.setVisibility(View.VISIBLE);
        textViewResult.setText(userCheck);
        bNext2.setVisibility(View.INVISIBLE);
        bNext3.setVisibility(View.INVISIBLE);
        bNextSur0.setVisibility(View.INVISIBLE);
        bNextSur.setVisibility(View.INVISIBLE);
        bNextSur2.setVisibility(View.VISIBLE);
        bBackHome.setVisibility(View.INVISIBLE);
    }
    public void bNextSur2Clicked(View v){
        bStart.setVisibility(View.INVISIBLE);
        bInstruction.setVisibility(View.INVISIBLE);
        bScore.setVisibility(View.INVISIBLE);
        TextView textView =(TextView) findViewById(R.id.textView2);
        textView.setVisibility(View.INVISIBLE);
        bBack2.setVisibility(View.VISIBLE);
        bPeace.setVisibility(View.INVISIBLE);
        bSurvive.setVisibility(View.INVISIBLE);
        bHard.setVisibility(View.INVISIBLE);
        TextView textView3 =(TextView) findViewById(R.id.textView3);
        textView3.setVisibility(View.VISIBLE);
        TextView textViewResult = (TextView) findViewById(R.id.textViewResult);
        textViewResult.setVisibility(View.INVISIBLE);
        TextView textViewRan =(TextView) findViewById(R.id.textViewRandom);
        Random random = new Random();
        int randomNum = random.nextInt(50);
        randArraySurvive.add(randomNum);
        textViewRan.setText(Integer.toString(randomNum));
        textViewRan.setVisibility(View.VISIBLE);
        bNext.setVisibility(View.INVISIBLE);
        EditText editTextInput = (EditText) findViewById(R.id.editTextInput);
        editTextInput.setVisibility(View.INVISIBLE);
        bNext2.setVisibility(View.INVISIBLE);
        bNext3.setVisibility(View.INVISIBLE);
        bNextSur0.setVisibility(View.VISIBLE);
        bNextSur.setVisibility(View.INVISIBLE);
        bNextSur2.setVisibility(View.INVISIBLE);
        bBackHome.setVisibility(View.INVISIBLE);

    }
    public void bHardClicked(View v){
        Random random = new Random();
        int randomNum = random.nextInt(999);
        randArrayHardcore.add(randomNum);
        TextView textViewRandom =(TextView) findViewById(R.id.textViewRandom);
        textViewRandom.setText(Integer.toString(randomNum));
        bStart.setVisibility(View.INVISIBLE);
        bInstruction.setVisibility(View.INVISIBLE);
        bScore.setVisibility(View.INVISIBLE);
        TextView textView =(TextView) findViewById(R.id.textView2);
        textView.setVisibility(View.INVISIBLE);
        bBack2.setVisibility(View.VISIBLE);
        bPeace.setVisibility(View.INVISIBLE);
        bSurvive.setVisibility(View.INVISIBLE);
        bHard.setVisibility(View.INVISIBLE);
        TextView textView3 =(TextView) findViewById(R.id.textView3);
        textView3.setVisibility(View.VISIBLE);
        TextView textViewRan =(TextView) findViewById(R.id.textViewRandom);
        textViewRan.setVisibility(View.VISIBLE);
        bNextSur0.setVisibility(View.INVISIBLE);
        bNext.setVisibility(View.INVISIBLE);
        bNextSur.setVisibility(View.INVISIBLE);
        bNextHar0.setVisibility(View.VISIBLE);
        bNextHar1.setVisibility(View.INVISIBLE);
        bBackHome.setVisibility(View.INVISIBLE);

    }
    public void bNextHar0Clicked(View v){
        bStart.setVisibility(View.INVISIBLE);
        bInstruction.setVisibility(View.INVISIBLE);
        bScore.setVisibility(View.INVISIBLE);
        TextView textView =(TextView) findViewById(R.id.textView2);
        textView.setVisibility(View.INVISIBLE);
        bBack2.setVisibility(View.INVISIBLE);
        bPeace.setVisibility(View.INVISIBLE);
        bSurvive.setVisibility(View.INVISIBLE);
        bHard.setVisibility(View.INVISIBLE);
        TextView textView3 =(TextView) findViewById(R.id.textView3);
        textView3.setVisibility(View.INVISIBLE);
        TextView textViewRan =(TextView) findViewById(R.id.textViewRandom);
        textViewRan.setVisibility(View.INVISIBLE);
        bNext.setVisibility(View.VISIBLE);
        EditText editTextInput = (EditText) findViewById(R.id.editTextInput);
        editTextInput.setVisibility(View.VISIBLE);
        bNext.setVisibility(View.INVISIBLE);
        bNext2.setVisibility(View.INVISIBLE);
        bNextSur0.setVisibility(View.INVISIBLE);
        bNextSur.setVisibility(View.INVISIBLE);
        bNextSur2.setVisibility(View.INVISIBLE);
        bNextHar0.setVisibility(View.INVISIBLE);
        bNextHar1.setVisibility(View.VISIBLE);
        bBackHome.setVisibility(View.INVISIBLE);

    }
    public void bNextHar1Clicked(View v){
        bStart.setVisibility(View.INVISIBLE);
        bInstruction.setVisibility(View.INVISIBLE);
        bScore.setVisibility(View.INVISIBLE);
        TextView textView =(TextView) findViewById(R.id.textView2);
        textView.setVisibility(View.INVISIBLE);
        bBack2.setVisibility(View.VISIBLE);
        bPeace.setVisibility(View.INVISIBLE);
        bSurvive.setVisibility(View.INVISIBLE);
        bHard.setVisibility(View.INVISIBLE);
        TextView textView3 =(TextView) findViewById(R.id.textView3);
        textView3.setVisibility(View.INVISIBLE);
        TextView textViewRan =(TextView) findViewById(R.id.textViewRandom);
        textViewRan.setVisibility(View.INVISIBLE);
        bNext.setVisibility(View.INVISIBLE);
        EditText editTextInput = (EditText) findViewById(R.id.editTextInput);
        editTextInput.setVisibility(View.INVISIBLE);
        String arr = randArrayHardcore.toString();
        String user = editTextInput.getText().toString();
        String userCheck = RandomGen.rndCheck(arr, user);
        TextView textViewResult = (TextView) findViewById(R.id.textViewResult);
        textViewResult.setVisibility(View.VISIBLE);
        textViewResult.setText(userCheck);
        bNext2.setVisibility(View.INVISIBLE);
        bNext3.setVisibility(View.INVISIBLE);
        bNextSur0.setVisibility(View.INVISIBLE);
        bNextSur.setVisibility(View.INVISIBLE);
        bNextSur2.setVisibility(View.INVISIBLE);
        bNextHar0.setVisibility(View.INVISIBLE);
        bNextHar1.setVisibility(View.INVISIBLE);
        bNextHard2.setVisibility(View.VISIBLE);
        bBackHome.setVisibility(View.INVISIBLE);

    }
    public void bNextHar2Clicked(View v){
        bStart.setVisibility(View.INVISIBLE);
        bInstruction.setVisibility(View.INVISIBLE);
        bScore.setVisibility(View.INVISIBLE);
        TextView textView =(TextView) findViewById(R.id.textView2);
        textView.setVisibility(View.INVISIBLE);
        bBack2.setVisibility(View.VISIBLE);
        bPeace.setVisibility(View.INVISIBLE);
        bSurvive.setVisibility(View.INVISIBLE);
        bHard.setVisibility(View.INVISIBLE);
        TextView textView3 =(TextView) findViewById(R.id.textView3);
        textView3.setVisibility(View.VISIBLE);
        TextView textViewResult = (TextView) findViewById(R.id.textViewResult);
        textViewResult.setVisibility(View.INVISIBLE);
        TextView textViewRan =(TextView) findViewById(R.id.textViewRandom);
        Random random = new Random();
        int randomNum = random.nextInt(100);
        randArrayHardcore.add(randomNum);
        textViewRan.setText(Integer.toString(randomNum));
        textViewRan.setVisibility(View.VISIBLE);
        bNext.setVisibility(View.INVISIBLE);
        EditText editTextInput = (EditText) findViewById(R.id.editTextInput);
        editTextInput.setVisibility(View.INVISIBLE);
        bNext2.setVisibility(View.INVISIBLE);
        bNext3.setVisibility(View.INVISIBLE);
        bNextSur0.setVisibility(View.INVISIBLE);
        bNextSur.setVisibility(View.INVISIBLE);
        bNextSur2.setVisibility(View.INVISIBLE);
        bNextHar0.setVisibility(View.VISIBLE);
        bNextHar1.setVisibility(View.INVISIBLE);
        bNextHard2.setVisibility(View.INVISIBLE);
        bBackHome.setVisibility(View.INVISIBLE);

    }
    public void bBackHomeClicked(View v){
        bStart.setVisibility(View.VISIBLE);
        bInstruction.setVisibility(View.VISIBLE);
        bScore.setVisibility(View.VISIBLE);
        bBack2.setVisibility(View.INVISIBLE);
        bPeace.setVisibility(View.INVISIBLE);
        bSurvive.setVisibility(View.INVISIBLE);
        bHard.setVisibility(View.INVISIBLE);
        bNext.setVisibility(View.INVISIBLE);
        bNext2.setVisibility(View.INVISIBLE);
        bNext3.setVisibility(View.INVISIBLE);
        bNextSur.setVisibility(View.INVISIBLE);
        bNextSur2.setVisibility(View.INVISIBLE);
        bNextSur0.setVisibility(View.INVISIBLE);
        bNextHar0.setVisibility(View.INVISIBLE);
        bNextHar1.setVisibility(View.INVISIBLE);
        bNextHard2.setVisibility(View.INVISIBLE);
        bBackHome.setVisibility(View.INVISIBLE);
        TextView textViewScore =(TextView) findViewById(R.id.textViewScore);
        textViewScore.setVisibility(View.INVISIBLE);
    }




}


