package com.example.randomnumbermemorization;

import java.util.ArrayList;

public class RandomGen {
    public static String rndCheck(String a, String b){
        String n = "[" + b + "]";
        if (a.equals(n)) {
            return "Correct, noice";
        } else {
            return "Wrooongg answer is: " + a +" you typed "+ n;

        }

    }


}
